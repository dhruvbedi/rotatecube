"use strict";

exports.oldURL = function (e) {
  return e.oldURL;
};

exports.newURL = function (e) {
  return e.newURL;
};
