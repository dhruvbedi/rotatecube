"use strict";

exports.data_ = function (e) {
  return e.data;
};
