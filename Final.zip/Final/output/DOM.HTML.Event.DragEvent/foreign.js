"use strict";

exports.dataTransfer = function (e) {
  return e.dataTransfer;
};
